#!/bin/bash
# AGENT 1 - Interface : reçoit les messages de l'utilisateur

echo "🤖 Bonjour ! Je suis ChatBot. Tape 'quitter' pour arrêter."
echo "---------------------------------------------------"

while true; do
    # Demander une saisie à l'utilisateur
    echo -n "Vous : "
    read message

    # Envoyer le message à l'agent cerveau
    echo "$message" > /tmp/message_entrant.txt

    # Appeler l'agent cerveau
    bash ~/Desktop/UNIX/chatbot/agent_brain.sh

    # Lire et afficher la réponse
    reponse=$(cat /tmp/reponse.txt)
    echo "🤖 $reponse"
    echo ""

    # Condition pour quitter
    if [ "$message" = "quitter" ]; then
        break
    fi
done
