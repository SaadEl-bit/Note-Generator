#!/bin/bash
# AGENT 2 - Cerveau : analyse le message et prépare la réponse

# Lire le message envoyé par l'agent interface
message=$(cat /tmp/message_entrant.txt)

# Convertir en minuscules pour comparer facilement
message_lower=$(echo "$message" | tr '[:upper:]' '[:lower:]')

# Logique de réponse selon les mots-clés
if [ "$message_lower" = "bonjour" ] || [ "$message_lower" = "salut" ] || [ "$message_lower" = "hello" ]; then
    echo "Salut ! Comment puis-je vous aider ?" > /tmp/reponse.txt

elif [ "$message_lower" = "comment tu t'appelles" ] || [ "$message_lower" = "ton nom" ]; then
    echo "Je m'appelle ChatBot, votre assistant Bash !" > /tmp/reponse.txt

elif echo "$message_lower" | grep -q "heure"; then
    heure=$(date +"%H:%M:%S")
    echo "Il est actuellement $heure" > /tmp/reponse.txt

elif echo "$message_lower" | grep -q "date"; then
    date_auj=$(date +"%d/%m/%Y")
    echo "Nous sommes le $date_auj" > /tmp/reponse.txt

elif echo "$message_lower" | grep -q "fichier"; then
    liste=$(ls ~/Desktop/UNIX/chatbot/)
    echo "Fichiers dans le projet : $liste" > /tmp/reponse.txt

elif [ "$message_lower" = "quitter" ]; then
    echo "Au revoir ! À bientôt 👋" > /tmp/reponse.txt

else
    echo "Je n'ai pas compris. Essaie : bonjour, heure, date, fichier" > /tmp/reponse.txt
fi

# Appeler l'agent output pour logger la réponse
bash ~/Desktop/UNIX/chatbot/agent_output.sh
