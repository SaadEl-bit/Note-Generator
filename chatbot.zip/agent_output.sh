#!/bin/bash
# AGENT 3 - Output : enregistre chaque échange dans un fichier log

message=$(cat /tmp/message_entrant.txt)
reponse=$(cat /tmp/reponse.txt)
heure=$(date +"%H:%M:%S")

# Écrire dans le fichier log
echo "[$heure] Vous : $message" >> ~/Desktop/UNIX/chatbot/historique.log
echo "[$heure] Bot  : $reponse" >> ~/Desktop/UNIX/chatbot/historique.log
echo "---" >> ~/Desktop/UNIX/chatbot/historique.log
